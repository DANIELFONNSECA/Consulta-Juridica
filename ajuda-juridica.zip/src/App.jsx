
import React, { useState } from "react";

export default function App() {
  const [pergunta, setPergunta] = useState("");
  const [resposta, setResposta] = useState("");
  const [carregando, setCarregando] = useState(false);

  const enviarPergunta = async () => {
    setCarregando(true);
    const res = await fetch("/api/pergunta", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pergunta }),
    });
    const data = await res.json();
    setResposta(data.resposta);
    setCarregando(false);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
      <div className="bg-white p-6 rounded-xl shadow-md w-full max-w-xl">
        <h1 className="text-2xl font-bold mb-4 text-center text-blue-600">Ajuda Jurídica</h1>
        <textarea
          className="w-full p-3 border border-gray-300 rounded-lg mb-4"
          placeholder="Digite sua dúvida jurídica aqui..."
          rows={4}
          value={pergunta}
          onChange={(e) => setPergunta(e.target.value)}
        />
        <button
          onClick={enviarPergunta}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 w-full"
          disabled={carregando}
        >
          {carregando ? "Consultando..." : "Enviar"}
        </button>
        {resposta && (
          <div className="mt-6 bg-gray-50 p-4 rounded-lg border border-gray-200 whitespace-pre-wrap">
            {resposta}
            <div className="mt-4 text-center">
              <a
                href="https://wa.me/SEUNUMERO?text=Olá%2C%20gostaria%20de%20agendar%20uma%20consulta%20jurídica."
                target="_blank"
                className="inline-block bg-green-500 text-white px-4 py-2 mt-2 rounded hover:bg-green-600"
              >
                Agendar Consulta com Valor Promocional
              </a>
            </div>
          </div>
        )}
        <p className="mt-6 text-sm text-gray-500 text-center">
          💡 Você sabia que pode ter direito ao BPC/LOAS mesmo sem ter contribuído ao INSS?
        </p>
      </div>
    </div>
  );
}
