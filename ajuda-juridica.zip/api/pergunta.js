
import { OpenAI } from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).end("Apenas POST");
  }

  const { pergunta } = req.body;

  try {
    const resposta = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content:
            "Você é um assistente jurídico que responde de forma simples, clara e educativa. No final, sempre sugira que o usuário agende uma consulta.",
        },
        { role: "user", content: pergunta },
      ],
    });

    res.json({ resposta: resposta.choices[0].message.content });
  } catch (error) {
    console.error(error);
    res.status(500).json({ erro: "Erro ao consultar a IA." });
  }
}
