# Ajuda Jurídica

Chat jurídico com inteligência artificial usando OpenAI e Next.js.